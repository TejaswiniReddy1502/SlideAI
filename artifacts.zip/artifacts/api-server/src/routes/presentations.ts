import OpenAI from "openai";
import { Router, type IRouter } from "express";
import {
  GeneratePresentationBody,
  GeneratePresentationImageBody,
  GeneratePresentationImageResponse,
  GeneratePresentationResponse,
  RegeneratePresentationSlideBody,
  RegeneratePresentationSlideResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const presentationStyle: Record<string, string> = {
  professional: "professional, clear, and credible",
  minimal: "minimal, focused, and easy to scan",
  bold: "bold, energetic, and memorable",
  academic: "evidence-led, precise, and appropriately nuanced",
  narrative: "story-driven, engaging, and cohesive",
};

function getOpenAIClient(): OpenAI | null {
  const apiKey = process.env.OPENAI_API_KEY;
  return apiKey ? new OpenAI({ apiKey }) : null;
}

function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Unknown AI service error";
}

router.post("/presentations/generate", async (req, res): Promise<void> => {
  const parsed = GeneratePresentationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Check the presentation settings and try again." });
    return;
  }

  const client = getOpenAIClient();
  if (!client) {
    res.status(503).json({ error: "AI generation is not configured. Add an OpenAI API key in Replit Secrets." });
    return;
  }

  const { topic, title, slideCount, audience, language, style } = parsed.data;
  try {
    const completion = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You create accurate, useful presentation drafts. Return only a JSON object matching this shape: {title:string, topic:string, slides:[{title:string, bullets:string[], explanation:string, visualSuggestion:string}]}. Write all content in the requested language. Each slide needs 2-5 concise bullets, one brief explanatory paragraph, and a concrete visual suggestion. Make the narrative coherent from opening to conclusion, avoid repeated points, and do not invent citations or statistics. Do not include markdown.",
        },
        {
          role: "user",
          content: JSON.stringify({
            topic,
            presentationTitle: title || null,
            exactSlideCount: slideCount,
            targetAudience: audience,
            language,
            style: presentationStyle[style] ?? "professional and clear",
            instructions: `Create exactly ${slideCount} slides. Include a useful opening and a conclusion. Keep slide text concise and appropriate for the audience.`,
          }),
        },
      ],
    });
    const content = completion.choices[0]?.message?.content;
    if (!content) {
      res.status(502).json({ error: "The AI returned an empty presentation. Please try again." });
      return;
    }

    let generated: unknown;
    try {
      generated = JSON.parse(content);
    } catch {
      res.status(502).json({ error: "The AI returned an unreadable draft. Please try again." });
      return;
    }

    const validated = GeneratePresentationResponse.safeParse(generated);
    if (!validated.success || validated.data.slides.length !== slideCount) {
      req.log.warn(
        { expectedSlides: slideCount, receivedSlides: validated.success ? validated.data.slides.length : null },
        "AI presentation output did not match the requested structure",
      );
      res.status(502).json({ error: "The AI could not create a complete draft this time. Please try again." });
      return;
    }

    res.json({
      ...validated.data,
      title: title?.trim() || validated.data.title,
      topic,
      slides: validated.data.slides.map((slide) => ({ ...slide, imageDataUri: null })),
    });
  } catch (error) {
    req.log.error({ errorName: error instanceof Error ? error.name : "UnknownError" }, "Presentation generation failed");
    res.status(502).json({ error: "Presentation generation failed. Check your API key or try again shortly." });
  }
});

router.post("/presentations/regenerate-slide", async (req, res): Promise<void> => {
  const parsed = RegeneratePresentationSlideBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Check the slide content and try again." });
    return;
  }

  const client = getOpenAIClient();
  if (!client) {
    res.status(503).json({ error: "AI generation is not configured. Add an OpenAI API key in Replit Secrets." });
    return;
  }

  const { topic, audience, language, style, slideNumber, totalSlides, currentSlide, neighboringTitles } = parsed.data;
  try {
    const completion = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "Rewrite one presentation slide while maintaining the deck's narrative. Return only a JSON object with title:string, bullets:string[] (2-5 concise items), explanation:string, and visualSuggestion:string. Use the requested language, do not repeat neighboring slide titles, and do not invent citations or statistics.",
        },
        {
          role: "user",
          content: JSON.stringify({
            topic,
            audience,
            language,
            style: presentationStyle[style] ?? "professional and clear",
            slideNumber,
            totalSlides,
            currentSlide,
            neighboringSlideTitles: neighboringTitles,
          }),
        },
      ],
    });
    const content = completion.choices[0]?.message?.content;
    if (!content) {
      res.status(502).json({ error: "The AI returned an empty slide. Please try again." });
      return;
    }

    let generated: unknown;
    try {
      generated = JSON.parse(content);
    } catch {
      res.status(502).json({ error: "The AI returned an unreadable slide. Please try again." });
      return;
    }

    const validated = RegeneratePresentationSlideResponse.safeParse(generated);
    if (!validated.success) {
      res.status(502).json({ error: "The AI could not create a complete slide. Please try again." });
      return;
    }
    res.json({ ...validated.data, imageDataUri: null });
  } catch (error) {
    req.log.error({ errorName: error instanceof Error ? error.name : "UnknownError" }, "Slide regeneration failed");
    res.status(502).json({ error: "Slide regeneration failed. Check your API key or try again shortly." });
  }
});

router.post("/presentations/generate-image", async (req, res): Promise<void> => {
  const parsed = GeneratePresentationImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Check the slide content and try again." });
    return;
  }

  const client = getOpenAIClient();
  if (!client) {
    res.status(503).json({ error: "AI image generation is not configured. Add an OpenAI API key in Replit Secrets." });
    return;
  }

  const { topic, slideTitle, explanation, bullets, style } = parsed.data;
  const prompt = [
    "Create a polished landscape 3:2 illustration for one presentation slide.",
    `Subject: ${topic}.`,
    `Slide focus: ${slideTitle}.`,
    `Context: ${explanation}.`,
    `Key concepts: ${bullets.join("; ")}.`,
    `Visual direction: ${presentationStyle[style] ?? "professional and clear"}.`,
    "Use an editorial illustration, diagram, or conceptual visual appropriate to the subject. Keep it legible and uncluttered. Do not render words, letters, captions, labels, watermarks, or logos.",
  ].join(" ");

  try {
    const image = await client.images.generate({
      model: "gpt-image-1",
      prompt,
      size: "1536x1024",
    });
    const base64 = image.data?.[0]?.b64_json;
    if (!base64) {
      res.status(502).json({ error: "The image service returned no image. Please try again." });
      return;
    }

    res.json(GeneratePresentationImageResponse.parse({ imageDataUri: `data:image/png;base64,${base64}` }));
  } catch (error) {
    req.log.error({ errorName: error instanceof Error ? error.name : "UnknownError" }, "Slide image generation failed");
    res.status(502).json({ error: "Image generation failed. Check your API key or try again shortly." });
  }
});

export default router;
