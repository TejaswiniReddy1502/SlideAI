import { type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import pptxgen from 'pptxgenjs';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  useGeneratePresentation,
  useGeneratePresentationImage,
  useRegeneratePresentationSlide,
} from '@workspace/api-client-react';
import type { GeneratePresentationInput, Presentation, PresentationSlide } from '@workspace/api-client-react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, BookOpen, Check, ChevronLeft, ChevronRight,
  Download, FileImage, FileText, ImagePlus, Layers3, LoaderCircle, Minus, Plus, RotateCw,
  Sparkles, Trash2, WandSparkles, X,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();
const STORAGE_KEY = 'folio-presentation-workspace-v1';
type Style = GeneratePresentationInput['style'];
type Options = { topic: string; title: string; slideCount: number; audience: string; language: string; style: Style };
type SavedWorkspace = { options: Options; presentation: Presentation | null };
const defaults: Options = { topic: '', title: '', slideCount: 8, audience: 'General audience', language: 'English', style: 'professional' };
const styles: { id: Style; title: string; note: string; glyph: string }[] = [
  { id: 'professional', title: 'Professional', note: 'Clear & assured', glyph: '01' },
  { id: 'minimal', title: 'Minimal', note: 'Room to breathe', glyph: '02' },
  { id: 'bold', title: 'Bold', note: 'High contrast', glyph: '03' },
  { id: 'academic', title: 'Academic', note: 'Evidence-led', glyph: '04' },
  { id: 'narrative', title: 'Narrative', note: 'A story arc', glyph: '05' },
];

function restoreWorkspace(): SavedWorkspace {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<SavedWorkspace>;
      return { options: { ...defaults, ...(parsed.options ?? {}) }, presentation: parsed.presentation ?? null };
    }
  } catch { /* Keep the fresh workspace when stored data is unreadable. */ }
  return { options: defaults, presentation: null };
}

async function savePptx(presentation: Presentation, style: Style): Promise<void> {
  const deck = new pptxgen();
  deck.layout = 'LAYOUT_WIDE';
  deck.author = 'Folio Presentation Studio';
  deck.subject = presentation.topic;
  deck.title = presentation.title || presentation.topic;
  deck.theme = { headFontFace: 'Aptos Display', bodyFontFace: 'Aptos' };
  const accent = style === 'bold' ? 'C65D45' : style === 'academic' ? '527667' : 'B9664E';

  presentation.slides.forEach((content, index) => {
    const slide = deck.addSlide();
    const hasImage = Boolean(content.imageDataUri);
    slide.background = { color: 'F8F4E9' };
    slide.addText(presentation.title || 'PRESENTATION', {
      x: 0.7, y: 0.35, w: 10.8, h: 0.25, fontFace: 'Aptos', fontSize: 9,
      charSpacing: 1.2, color: '627080', margin: 0,
    });
    slide.addText(String(index + 1).padStart(2, '0'), {
      x: 12.0, y: 0.32, w: 0.55, h: 0.25, fontFace: 'Aptos', fontSize: 10,
      color: accent, align: 'right', margin: 0,
    });
    slide.addShape(deck.ShapeType.line, {
      x: 0.7, y: 0.76, w: 11.85, h: 0, line: { color: 'D8D4C9', width: 1 },
    });
    slide.addText(content.title || 'Untitled slide', {
      x: 0.72, y: 1.05, w: hasImage ? 7.2 : 11.1, h: 0.8,
      fontFace: 'Aptos Display', fontSize: 30, bold: true, color: '26354A',
      breakLine: false, fit: 'shrink', margin: 0,
    });

    const textWidth = hasImage ? 7.0 : 11.0;
    content.bullets.filter((bullet) => bullet.trim()).forEach((bullet, bulletIndex) => {
      slide.addText(`•  ${bullet}`, {
        x: 0.8, y: 2.0 + bulletIndex * 0.48, w: textWidth, h: 0.4,
        fontFace: 'Aptos', fontSize: 17, color: '39495A', breakLine: false,
        fit: 'shrink', margin: 0,
      });
    });
    slide.addText(content.explanation || '', {
      x: 0.82, y: 4.25, w: textWidth, h: 0.8,
      fontFace: 'Aptos', fontSize: 13, color: '566473', fit: 'shrink',
      valign: 'top', margin: 0,
    });
    slide.addText('VISUAL DIRECTION', {
      x: 0.82, y: 5.35, w: 2.4, h: 0.22,
      fontFace: 'Aptos', fontSize: 8, bold: true, charSpacing: 1.2,
      color: accent, margin: 0,
    });
    slide.addText(content.visualSuggestion || '', {
      x: 0.82, y: 5.62, w: textWidth, h: 0.52,
      fontFace: 'Aptos', fontSize: 11, color: '566473', fit: 'shrink',
      valign: 'top', margin: 0,
    });
    if (content.imageDataUri) {
      slide.addImage({ data: content.imageDataUri, x: 8.35, y: 2.0, w: 4.0, h: 2.8 });
    }
    slide.addText(`${String(index + 1).padStart(2, '0')}  —  ${style.toUpperCase()}`, {
      x: 9.0, y: 7.0, w: 3.55, h: 0.2, fontFace: 'Aptos', fontSize: 8,
      color: '7B858F', align: 'right', margin: 0,
    });
  });

  const filename = (presentation.title || 'presentation')
    .trim()
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, '-')
    .slice(0, 100);
  await deck.writeFile({ fileName: `${filename || 'presentation'}.pptx` });
}

function IconButton({ label, onClick, children, disabled = false, tone = 'quiet', testId }: { label: string; onClick: () => void; children: ReactNode; disabled?: boolean; tone?: 'quiet' | 'danger'; testId: string }) {
  return <button type="button" aria-label={label} title={label} data-testid={testId} disabled={disabled} onClick={onClick} className={`icon-button ${tone === 'danger' ? 'danger' : ''}`}>{children}</button>;
}

function Workspace() {
  const [location, setLocation] = useLocation();
  const [saved, setSaved] = useState<SavedWorkspace>(restoreWorkspace);
  const [activeIndex, setActiveIndex] = useState(0);
  const [saveState, setSaveState] = useState<'saved' | 'saving' | 'error'>('saved');
  const [apiError, setApiError] = useState('');
  const generation = useGeneratePresentation();
  const regenerate = useRegeneratePresentationSlide();
  const imageGenerator = useGeneratePresentationImage();
  const options = saved.options;
  const presentation = saved.presentation;
  const slides = presentation?.slides ?? [];
  const currentSlide = slides[activeIndex];
  const isPending = generation.isPending || regenerate.isPending || imageGenerator.isPending;

  useEffect(() => {
    setSaveState('saving');
    const timer = window.setTimeout(() => {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(saved)); setSaveState('saved'); } catch { setSaveState('error'); }
    }, 250);
    return () => window.clearTimeout(timer);
  }, [saved]);

  useEffect(() => {
    if (activeIndex >= slides.length) setActiveIndex(Math.max(0, slides.length - 1));
  }, [activeIndex, slides.length]);

  const updateOptions = (patch: Partial<Options>) => setSaved((prev) => ({ ...prev, options: { ...prev.options, ...patch } }));
  const updatePresentation = (next: Presentation) => setSaved((prev) => ({ ...prev, presentation: next }));
  const updateSlide = (index: number, patch: Partial<PresentationSlide>) => {
    if (!presentation) return;
    const nextSlides = presentation.slides.map((slide, i) => i === index ? { ...slide, ...patch } : slide);
    updatePresentation({ ...presentation, slides: nextSlides });
  };

  const onGenerate = () => {
    if (options.topic.trim().length < 3) { setApiError('Add a topic with at least three characters to begin.'); return; }
    if (!options.audience.trim()) { setApiError('Add a target audience so the slide content can be tailored.'); return; }
    setApiError('');
    generation.mutate({ data: { topic: options.topic.trim(), title: options.title.trim() || undefined, slideCount: options.slideCount, audience: options.audience, language: options.language, style: options.style } }, {
      onSuccess: (result) => { setSaved((prev) => ({ ...prev, options: { ...prev.options, title: result.title }, presentation: result })); setActiveIndex(0); setLocation('/'); },
      onError: (error) => setApiError(error instanceof Error ? error.message : 'The deck could not be generated. Please try again.'),
    });
  };

  const regenerateSlide = () => {
    if (!presentation || !currentSlide) return;
    setApiError('');
    regenerate.mutate({ data: { topic: presentation.topic, audience: options.audience, language: options.language, style: options.style, slideNumber: activeIndex + 1, totalSlides: slides.length, currentSlide, neighboringTitles: slides.filter((_, i) => i !== activeIndex).map((slide) => slide.title) } }, {
      onSuccess: (result) => updateSlide(activeIndex, result),
      onError: (error) => setApiError(error instanceof Error ? error.message : 'This slide could not be regenerated.'),
    });
  };

  const generateImage = () => {
    if (!presentation || !currentSlide) return;
    setApiError('');
    imageGenerator.mutate({ data: { topic: presentation.topic, slideTitle: currentSlide.title, explanation: currentSlide.explanation, bullets: currentSlide.bullets, style: options.style } }, {
      onSuccess: (result) => updateSlide(activeIndex, { imageDataUri: result.imageDataUri }),
      onError: (error) => setApiError(error instanceof Error ? error.message : 'An illustration could not be generated.'),
    });
  };

  const deleteSlide = (index: number) => {
    if (!presentation || slides.length <= 3) return;
    if (!window.confirm(`Delete slide ${index + 1}: “${slides[index].title}”?`)) return;
    updatePresentation({ ...presentation, slides: slides.filter((_, i) => i !== index) });
  };
  const moveSlide = (index: number, direction: -1 | 1) => {
    if (!presentation) return;
    const target = index + direction; if (target < 0 || target >= slides.length) return;
    const next = [...slides]; [next[index], next[target]] = [next[target], next[index]];
    updatePresentation({ ...presentation, slides: next }); setActiveIndex(target);
  };
  const addSlide = () => {
    if (!presentation || slides.length >= 20) return;
    const next = [...slides, { title: 'New slide', bullets: ['Add a key idea', 'Add supporting detail'], explanation: '', visualSuggestion: 'Add a visual direction', imageDataUri: null }];
    updatePresentation({ ...presentation, slides: next }); setActiveIndex(next.length - 1);
  };

  const exportPDF = () => window.print();
  const exportPptx = async () => {
    if (!presentation) return;
    setApiError('');
    try {
      await savePptx(presentation, options.style);
    } catch {
      setApiError('The PowerPoint file could not be created. Please try again.');
    }
  };

  const preview = location === '/preview';
  const percent = useMemo(() => Math.round(((activeIndex + 1) / Math.max(slides.length, 1)) * 100), [activeIndex, slides.length]);

  return (
    <div className={`app-shell grain ${preview ? 'preview-route' : ''}`}>
      <header className="topbar">
        <Link href="/" className="brand-lockup" data-testid="link-home">
          <span className="brand-mark"><Layers3 size={18} strokeWidth={2.2} /></span>
          <span className="brand-name">folio<span>.</span></span>
          <span className="brand-divider" />
          <span className="brand-product">Presentation studio</span>
        </Link>
        <div className="topbar-right">
          <div className="save-status" data-testid="status-save">
            <span className={`save-dot ${saveState}`} />{saveState === 'saving' ? 'Saving draft' : saveState === 'error' ? 'Draft could not save' : 'Draft saved'}
          </div>
          {presentation && !preview && <>
            <button type="button" className="top-action" onClick={() => setLocation('/preview')} data-testid="button-preview"><BookOpen size={16} /> Preview</button>
            <div className="export-group">
              <button type="button" className="top-action" onClick={exportPDF} data-testid="button-export-pdf"><FileText size={16} /> PDF</button>
              <button type="button" className="top-action" onClick={exportPptx} data-testid="button-export-pptx"><Download size={16} /> PPTX</button>
            </div>
          </>}
          {preview && <button type="button" className="top-action back-edit" onClick={() => setLocation('/')} data-testid="button-back-editor"><ArrowLeft size={16} /> Back to editing</button>}
        </div>
      </header>

      <Switch>
        <Route path="/preview">
          <main className="preview-page">
            {presentation && currentSlide ? <div className="preview-stage">
              <div className="preview-heading"><div><span className="eyebrow">PRESENTATION PREVIEW</span><h1>{presentation.title || presentation.topic}</h1></div><span className="preview-count font-mono-ui" data-testid="text-preview-count">{String(activeIndex + 1).padStart(2, '0')} <i>/</i> {String(slides.length).padStart(2, '0')}</span></div>
              <SlideCanvas slide={currentSlide} number={activeIndex + 1} title={presentation.title} style={options.style} />
              <div className="preview-controls">
                <button type="button" className="nav-arrow" disabled={activeIndex === 0} onClick={() => setActiveIndex((i) => Math.max(0, i - 1))} data-testid="button-preview-previous"><ChevronLeft /> Previous</button>
                <div className="progress-wrap" aria-label={`Slide ${activeIndex + 1} of ${slides.length}`}><div className="progress-track"><span style={{ width: `${percent}%` }} /></div><small>{percent}% through</small></div>
                <button type="button" className="nav-arrow next" disabled={activeIndex === slides.length - 1} onClick={() => setActiveIndex((i) => Math.min(slides.length - 1, i + 1))} data-testid="button-preview-next">Next <ChevronRight /></button>
              </div>
              <div className="preview-strip" data-testid="list-preview-thumbnails">
                {slides.map((slide, index) => <button key={`${index}-${slide.title}`} type="button" onClick={() => setActiveIndex(index)} className={`preview-thumb ${index === activeIndex ? 'selected' : ''}`} data-testid={`button-preview-slide-${index + 1}`}><span>{String(index + 1).padStart(2, '0')}</span><b>{slide.title}</b></button>)}
              </div>
            </div> : <EmptyState onGenerate={() => setLocation('/')} />}
          </main>
        </Route>
        <Route path="/">
          <main className="workbench">
            <aside className="setup-panel">
              <div className="panel-heading">
                <div><span className="eyebrow">01 — SET THE SCENE</span><h1>Start with a<br /><em>good question.</em></h1></div>
                <div className="number-stamp">F / 01</div>
              </div>
              <p className="intro-copy">A clear topic is the start of a presentation worth listening to.</p>
              <div className="form-stack">
                <label className="field-label" htmlFor="topic">What are we talking about?</label>
                <textarea id="topic" rows={3} placeholder="e.g. How cities can adapt to a hotter climate" value={options.topic} onChange={(e) => { const value = e.target.value; setSaved((prev) => ({ ...prev, options: { ...prev.options, topic: value }, presentation: prev.presentation ? { ...prev.presentation, topic: value } : null })); }} data-testid="input-topic" />
                <div className="field-row">
                  <div className="field-block"><label className="field-label" htmlFor="deck-title">Deck title <span>optional</span></label><input id="deck-title" value={options.title} onChange={(e) => { const value = e.target.value; setSaved((prev) => ({ ...prev, options: { ...prev.options, title: value }, presentation: prev.presentation ? { ...prev.presentation, title: value } : null })); }} placeholder="A title for your deck" maxLength={160} data-testid="input-title" /></div>
                  <div className="field-block count-field"><label className="field-label" htmlFor="slide-count">Slides</label><div className="stepper"><button type="button" aria-label="Fewer slides" onClick={() => updateOptions({ slideCount: Math.max(3, options.slideCount - 1) })} disabled={options.slideCount <= 3} data-testid="button-slide-count-decrease"><Minus size={14} /></button><input id="slide-count" value={options.slideCount} type="number" min={3} max={20} onChange={(e) => updateOptions({ slideCount: Math.min(20, Math.max(3, Number(e.target.value) || 3)) })} data-testid="input-slide-count" /><button type="button" aria-label="More slides" onClick={() => updateOptions({ slideCount: Math.min(20, options.slideCount + 1) })} disabled={options.slideCount >= 20} data-testid="button-slide-count-increase"><Plus size={14} /></button></div></div>
                </div>
                <div className="field-row">
                  <div className="field-block"><label className="field-label" htmlFor="audience">Made for</label><input id="audience" value={options.audience} onChange={(e) => updateOptions({ audience: e.target.value })} placeholder="e.g. First-year students" maxLength={120} data-testid="input-audience" /></div>
                  <div className="field-block"><label className="field-label" htmlFor="language">Language</label><select id="language" value={options.language} onChange={(e) => updateOptions({ language: e.target.value })} data-testid="select-language"><option>English</option><option>Spanish</option><option>French</option><option>German</option><option>Italian</option><option>Portuguese</option><option>Japanese</option><option>Mandarin Chinese</option><option>Arabic</option><option>Hindi</option></select></div>
                </div>
                <div className="style-heading"><label className="field-label">Choose a direction</label><span className="style-count">5 WAYS TO TELL IT</span></div>
                <div className="style-grid" role="radiogroup" aria-label="Presentation style">
                  {styles.map((style) => <button key={style.id} type="button" role="radio" aria-checked={options.style === style.id} className={`style-option ${options.style === style.id ? 'chosen' : ''}`} onClick={() => updateOptions({ style: style.id })} data-testid={`button-style-${style.id}`}><span className="style-glyph">{style.glyph}</span><span className="style-copy"><b>{style.title}</b><small>{style.note}</small></span>{options.style === style.id && <Check className="style-check" size={15} />}</button>)}
                </div>
              </div>
              {apiError && <div className="error-note" role="alert" data-testid="status-error"><X size={15} />{apiError}</div>}
              <button type="button" className="generate-button" onClick={onGenerate} disabled={generation.isPending} data-testid="button-generate">
                {generation.isPending ? <><LoaderCircle className="spin" size={17} /> Building your deck...</> : <><WandSparkles size={17} /> Generate presentation <ArrowRight size={17} /></>}
              </button>
              <div className="under-button"><span>Usually takes a few seconds</span><span className="key-hint">YOUR IDEAS, IN ORDER</span></div>
            </aside>

            <section className="editor-panel" aria-label="Presentation editor">
              <div className="editor-topline">
                <div><span className="eyebrow">02 — SHAPE THE STORY</span><h2>{presentation ? presentation.title || 'Your presentation' : 'Your deck takes shape here'}</h2></div>
                {presentation && <div className="editor-actions"><button type="button" className="outline-action" onClick={() => setLocation('/preview')} data-testid="button-open-preview"><BookOpen size={15} /> Preview</button><div className="more-menu-actions"><button type="button" className="outline-action compact-action" onClick={exportPDF} data-testid="button-editor-pdf"><FileText size={15} /><span>PDF</span></button><button type="button" className="outline-action compact-action" onClick={exportPptx} data-testid="button-editor-pptx"><Download size={15} /><span>PPTX</span></button></div></div>}
              </div>
              {generation.isPending ? <div className="loading-deck" data-testid="status-generating"><div className="loading-copy"><span className="loading-orbit"><Sparkles size={17} /></span><b>Finding the through-line</b><small>Arranging the ideas into a clear story...</small></div><div className="skeleton-slide"><span /><i /><i /><i /></div><div className="skeleton-list"><span /><span /><span /></div></div>
              : presentation && currentSlide ? <div className="editor-content">
                <div className="slide-workspace">
                  <div className="canvas-meta"><span className="canvas-label">CANVAS <b>{String(activeIndex + 1).padStart(2, '0')}</b> / {String(slides.length).padStart(2, '0')}</span><span className="canvas-hint">Changes save automatically</span></div>
                  <div className="canvas-frame">
                    <SlideCanvas slide={currentSlide} number={activeIndex + 1} title={presentation.title} style={options.style} />
                    {currentSlide.imageDataUri && <button type="button" className="remove-slide-art" aria-label="Remove illustration" onClick={() => updateSlide(activeIndex, { imageDataUri: null })} data-testid={`button-remove-slide-image-${activeIndex + 1}`}><X size={12} /></button>}
                  </div>
                  <div className="slide-actions">
                    <button type="button" className="text-action" onClick={regenerateSlide} disabled={regenerate.isPending} data-testid="button-regenerate-slide">{regenerate.isPending ? <LoaderCircle className="spin" size={15} /> : <RotateCw size={15} />} Regenerate this slide</button>
                    <button type="button" className="text-action" onClick={generateImage} disabled={imageGenerator.isPending} data-testid="button-generate-image">{imageGenerator.isPending ? <LoaderCircle className="spin" size={15} /> : <ImagePlus size={15} />} {currentSlide.imageDataUri ? 'Make a new illustration' : 'Add an illustration'}</button>
                  </div>
                </div>
                <div className="detail-panel">
                  <div className="detail-header"><span className="eyebrow">SLIDE {String(activeIndex + 1).padStart(2, '0')}</span><div className="detail-tools">
                    <IconButton label="Move slide earlier" onClick={() => moveSlide(activeIndex, -1)} disabled={activeIndex === 0} testId={`button-move-up-${activeIndex + 1}`}><ArrowUp size={15} /></IconButton>
                    <IconButton label="Move slide later" onClick={() => moveSlide(activeIndex, 1)} disabled={activeIndex >= slides.length - 1} testId={`button-move-down-${activeIndex + 1}`}><ArrowDown size={15} /></IconButton>
                    <IconButton label="Delete slide" onClick={() => deleteSlide(activeIndex)} disabled={slides.length <= 3} tone="danger" testId={`button-delete-slide-${activeIndex + 1}`}><Trash2 size={15} /></IconButton>
                  </div></div>
                  <label className="detail-label" htmlFor="edit-slide-title">Slide title</label>
                  <input id="edit-slide-title" className="edit-title" value={currentSlide.title} onChange={(e) => updateSlide(activeIndex, { title: e.target.value })} data-testid="input-slide-title" />
                  <label className="detail-label" htmlFor="edit-bullets">Key points <span>one per line</span></label>
                  <textarea id="edit-bullets" className="edit-bullets" value={currentSlide.bullets.join('\n')} rows={5} onChange={(e) => updateSlide(activeIndex, { bullets: e.target.value.split('\n') })} data-testid="input-slide-bullets" />
                  <label className="detail-label" htmlFor="edit-explanation">Speaker notes</label>
                  <textarea id="edit-explanation" className="edit-explanation" value={currentSlide.explanation} rows={4} onChange={(e) => updateSlide(activeIndex, { explanation: e.target.value })} data-testid="input-slide-explanation" />
                  <div className="visual-note"><FileImage size={15} /><div><b>Visual direction</b><textarea value={currentSlide.visualSuggestion} onChange={(e) => updateSlide(activeIndex, { visualSuggestion: e.target.value })} rows={2} aria-label="Visual direction" data-testid="input-slide-visual-suggestion" /></div></div>
                  <button type="button" className="add-slide-button" onClick={addSlide} disabled={slides.length >= 20} data-testid="button-add-slide"><Plus size={16} /> Add a slide</button>
                </div>
              </div> : <EmptyState onGenerate={() => { document.getElementById('topic')?.focus(); }} />}
              {presentation && <div className="slide-rail" data-testid="list-slide-rail">
                {slides.map((slide, index) => <button key={`${index}-${slide.title}`} type="button" className={`rail-card ${index === activeIndex ? 'active' : ''}`} onClick={() => setActiveIndex(index)} data-testid={`button-select-slide-${index + 1}`}>
                  <div className="rail-thumb"><div className="rail-thumb-title">{slide.title || 'Untitled slide'}</div><div className="rail-lines"><i /><i /><i /></div><span>{String(index + 1).padStart(2, '0')}</span></div><span className="rail-title">{slide.title || 'Untitled slide'}</span>
                </button>)}
                <button type="button" className="rail-add" onClick={addSlide} disabled={slides.length >= 20} aria-label="Add a slide" data-testid="button-add-slide-rail"><Plus size={19} /></button>
              </div>}
              <div className="editor-footer">
                <span><Sparkles className="footer-spark" size={12} /> Built around your point of view.</span>
                {presentation && <span className="footer-deck-info" data-testid="text-slide-total">{slides.length} slides <i /> {options.style}</span>}
              </div>
            </section>
          </main>
        </Route>
        <Route component={NotFound} />
      </Switch>
      <div className="print-deck" aria-hidden="true">{presentation?.slides.map((slide, index) => <SlideCanvas key={`print-${index}`} slide={slide} number={index + 1} title={presentation.title} style={options.style} />)}</div>
    </div>
  );
}

function SlideCanvas({ slide, number, title, style }: { slide: PresentationSlide; number: number; title: string; style: Style }) {
  const visualClass = style === 'bold' ? 'canvas-bold' : style === 'minimal' ? 'canvas-minimal' : style === 'academic' ? 'canvas-academic' : style === 'narrative' ? 'canvas-narrative' : 'canvas-professional';
  return <article className={`slide-paper slide-shadow slide-canvas ${visualClass} ${slide.imageDataUri ? 'has-art' : ''}`} data-testid={`slide-canvas-${number}`}>
    <div className="slide-topline"><span className="slide-brand">FOLIO <i> / </i> {title || 'PRESENTATION'}</span><span className="slide-number">{String(number).padStart(2, '0')}</span></div>
    <div className="slide-main">
      <span className="slide-kicker">A POINT TO REMEMBER</span>
      <h3 data-testid={`text-slide-heading-${number}`}>{slide.title || 'Untitled slide'}</h3>
      <div className="slide-rule" />
      <ul>{slide.bullets.filter((bullet) => bullet.trim()).map((bullet, index) => <li key={`${bullet}-${index}`}>{bullet}</li>)}</ul>
      {slide.explanation && <p className="slide-explanation">{slide.explanation}</p>}
      {slide.visualSuggestion && <div className="slide-visual-note"><span>VISUAL NOTE</span><p>{slide.visualSuggestion}</p></div>}
    </div>
    {slide.imageDataUri && <img className="slide-art-image" src={slide.imageDataUri} alt={`Generated illustration for ${slide.title}`} data-testid={`img-slide-art-${number}`} />}
    <div className="slide-bottomline"><span>{title || 'A clear story, well told'}</span><span>{String(number).padStart(2, '0')} <i>—</i> {style.toUpperCase()}</span></div>
  </article>;
}

function EmptyState({ onGenerate }: { onGenerate: () => void }) {
  return <div className="empty-workspace" data-testid="empty-workspace">
    <div className="empty-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="empty-paper paper-back" /><div className="empty-paper paper-front"><span className="paper-index">YOUR NEXT BIG IDEA</span><b>A story<br />taking shape.</b><i /></div><Sparkles className="art-spark spark-one" size={16} /><Sparkles className="art-spark spark-two" size={11} /></div>
    <span className="eyebrow">A FRESH CANVAS</span>
    <h3>Your subject has<br /><em>somewhere to go.</em></h3>
    <p>Set your topic and point of view. We’ll help you turn it into a presentation that feels considered, not assembled.</p>
    <button type="button" className="empty-cta" onClick={onGenerate} data-testid="button-start-writing">Start with a topic <ArrowRight size={16} /></button>
    <div className="empty-footnote"><span>01</span> TOPIC <i /> <span>02</span> STORY <i /> <span>03</span> PRESENT</div>
  </div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><RoutedErrorBoundary><Workspace /></RoutedErrorBoundary></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
